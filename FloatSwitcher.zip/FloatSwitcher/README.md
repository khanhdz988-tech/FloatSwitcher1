# ⚡ FloatSwitcher Dylib

Floating App Switcher - Chuyển app nhanh không cần vào đa nhiệm.

---

## 🚀 Hướng dẫn build trên GitHub Actions (không cần Mac)

### Bước 1 — Upload lên GitHub
```
1. Vào github.com → New repository
2. Đặt tên: FloatSwitcher
3. Chọn Public
4. Nhấn Create repository
```

### Bước 2 — Upload toàn bộ thư mục này
```
1. Kéo thả toàn bộ files vào trang repository vừa tạo
   (hoặc dùng GitHub Desktop)
2. Commit message: "Initial commit"
3. Nhấn Commit changes
```

### Bước 3 — Chạy build
```
1. Vào tab "Actions" trên GitHub
2. Chọn "Build FloatSwitcher Dylib"
3. Nhấn "Run workflow" → Run workflow
4. Chờ ~5-10 phút
```

### Bước 4 — Tải dylib
```
1. Khi build xong (dấu ✅ xanh)
2. Nhấn vào build đó
3. Cuộn xuống "Artifacts"
4. Tải "FloatSwitcher-dylib"
5. Giải nén → có file FloatSwitcher.dylib
```

### Bước 5 — Inject bằng TrollFools
```
1. Copy FloatSwitcher.dylib vào iPhone (qua AirDrop/Files)
2. Mở TrollFools
3. Chọn app của bạn
4. Nhấn Inject → chọn FloatSwitcher.dylib
5. Xác nhận → app tự khởi động lại
6. Floating button xuất hiện ở cạnh phải màn hình!
```

---

## 🎮 Cách sử dụng

| Hành động | Kết quả |
|-----------|---------|
| Tap vào nút ⚡ | Mở/đóng menu danh sách app |
| Kéo nút | Di chuyển tự do trên màn hình |
| Thả nút | Tự snap vào cạnh trái/phải |
| Tap vào app trong menu | Switch sang app đó ngay lập tức |
| Tap ↻ | Làm mới danh sách app đang chạy |
| Tap ngoài menu | Đóng menu |

---

## 📋 Yêu cầu

- iPhone có TrollStore + TrollFools
- iOS 14.0 – 17.x
- arm64 device

---

## 📁 Cấu trúc project

```
FloatSwitcher/
├── .github/
│   └── workflows/
│       └── build.yml       ← GitHub Actions tự động build
├── Sources/
│   ├── FloatingMenuManager.h
│   ├── FloatingMenuManager.m  ← Logic chính
│   └── Tweak.x             ← Hook vào app
├── Makefile
├── control
└── README.md
```
