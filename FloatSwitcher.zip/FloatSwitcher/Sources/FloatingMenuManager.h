#import <UIKit/UIKit.h>

// ─── Model ─────────────────────────────────────────────────────
@interface AppEntry : NSObject
@property (nonatomic, strong) NSString *bundleID;
@property (nonatomic, strong) NSString *displayName;
@property (nonatomic, strong) UIImage  *icon;
@end

// ─── Manager ───────────────────────────────────────────────────
@interface FloatingMenuManager : NSObject
    <UITableViewDataSource, UITableViewDelegate>

+ (instancetype)shared;
- (void)installOverlayInWindow:(UIWindow *)window;

@end
