#import "FloatingMenuManager.h"
#import <dlfcn.h>
#import <objc/runtime.h>

// ─── Private API Declarations ───────────────────────────────────
extern int SBSLaunchApplicationWithIdentifier(
    CFStringRef identifier, BOOL suspended);
extern CFArrayRef SBSCopyApplicationDisplayIdentifiers(
    BOOL onlyActive, BOOL unknown);

// ─── UIImage Private (icon thật của app) ───────────────────────
@interface UIImage (Private)
+ (UIImage *)_applicationIconImageForBundleIdentifier:(NSString *)bid
                                       roleIdentifier:(NSString *)role
                                               format:(int)format
                                                scale:(CGFloat)scale;
@end

// ─── Constants ─────────────────────────────────────────────────
static const CGFloat kBtnSize   = 52.f;
static const CGFloat kPanelW    = 240.f;
static const CGFloat kPanelH    = 360.f;
static const CGFloat kRowHeight = 52.f;
static const CGFloat kHeaderH   = 46.f;

// ─── AppEntry ──────────────────────────────────────────────────
@implementation AppEntry
@end

// ─── FloatingMenuManager ───────────────────────────────────────
@interface FloatingMenuManager ()
@property (nonatomic, strong) UIWindow        *overlayWindow;
@property (nonatomic, strong) UIButton        *fabButton;
@property (nonatomic, strong) UIView          *menuPanel;
@property (nonatomic, strong) UITableView     *tableView;
@property (nonatomic, strong) UILabel         *emptyLabel;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) NSArray<AppEntry *> *apps;
@property (nonatomic, assign) BOOL            menuOpen;
@property (nonatomic, assign) CGPoint         dragStartCenter;
@end

@implementation FloatingMenuManager

// ─── Singleton ─────────────────────────────────────────────────
+ (instancetype)shared {
    static FloatingMenuManager *s;
    static dispatch_once_t t;
    dispatch_once(&t, ^{ s = [self new]; });
    return s;
}

// ═══════════════════════════════════════════════════════════════
#pragma mark - Install Entry Point
// ═══════════════════════════════════════════════════════════════

- (void)installOverlayInWindow:(UIWindow *)hostWindow {
    // Tạo overlay window riêng biệt, nổi trên mọi thứ
    if (@available(iOS 13.0, *)) {
        UIWindowScene *scene =
            (UIWindowScene *)hostWindow.windowScene;
        _overlayWindow =
            [[UIWindow alloc] initWithWindowScene:scene];
    } else {
        _overlayWindow =
            [[UIWindow alloc]
                initWithFrame:UIScreen.mainScreen.bounds];
    }

    _overlayWindow.windowLevel =
        UIWindowLevelStatusBar + 999;
    _overlayWindow.backgroundColor =
        UIColor.clearColor;
    _overlayWindow.userInteractionEnabled = YES;

    // Root VC trong suốt
    UIViewController *rootVC = [UIViewController new];
    rootVC.view.backgroundColor = UIColor.clearColor;
    _overlayWindow.rootViewController = rootVC;
    [_overlayWindow makeKeyAndVisible];

    // Trả key window về app gốc
    [hostWindow makeKeyWindow];

    [self buildFAB:rootVC.view];
    [self buildPanel:rootVC.view];
}

// ═══════════════════════════════════════════════════════════════
#pragma mark - Build FAB
// ═══════════════════════════════════════════════════════════════

- (void)buildFAB:(UIView *)parent {
    _fabButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _fabButton.frame =
        CGRectMake(0, 0, kBtnSize, kBtnSize);

    // Style
    _fabButton.backgroundColor =
        [UIColor colorWithRed:0.07
                        green:0.07
                         blue:0.12
                        alpha:0.93];
    _fabButton.layer.cornerRadius  = kBtnSize / 2;
    _fabButton.layer.borderWidth   = 1.8f;
    _fabButton.layer.borderColor   =
        [UIColor colorWithRed:0.25
                        green:0.55
                         blue:1.0
                        alpha:1.0].CGColor;
    _fabButton.layer.shadowColor   = UIColor.blackColor.CGColor;
    _fabButton.layer.shadowOpacity = 0.55f;
    _fabButton.layer.shadowRadius  = 8.f;
    _fabButton.layer.shadowOffset  = CGSizeMake(0, 4);

    [self setFABIcon:@"square.grid.2x2.fill"];

    // Vị trí mặc định: cạnh phải, 60% từ trên xuống
    CGSize sc = UIScreen.mainScreen.bounds.size;
    _fabButton.center =
        CGPointMake(sc.width - kBtnSize / 2 - 6,
                    sc.height * 0.6);

    // Tap
    [_fabButton addTarget:self
                   action:@selector(onFABTap)
         forControlEvents:UIControlEventTouchUpInside];

    // Pan (kéo)
    UIPanGestureRecognizer *pan =
        [[UIPanGestureRecognizer alloc]
            initWithTarget:self
                    action:@selector(onFABPan:)];
    [_fabButton addGestureRecognizer:pan];

    [parent addSubview:_fabButton];
}

- (void)setFABIcon:(NSString *)name {
    UIImageSymbolConfiguration *cfg =
        [UIImageSymbolConfiguration
            configurationWithPointSize:20
                                weight:UIImageSymbolWeightMedium];
    UIImage *icon =
        [UIImage systemImageNamed:name
               withConfiguration:cfg];
    [_fabButton setImage:icon forState:UIControlStateNormal];
    _fabButton.tintColor =
        [UIColor colorWithRed:0.45
                        green:0.78
                         blue:1.0
                        alpha:1.0];
}

// ─── FAB Tap ────────────────────────────────────────────────────
- (void)onFABTap {
    if (_menuOpen) [self closeMenu];
    else           [self openMenu];
}

// ─── FAB Pan (kéo thả, snap vào cạnh) ─────────────────────────
- (void)onFABPan:(UIPanGestureRecognizer *)pan {
    UIView *parent = _fabButton.superview;
    CGPoint delta  = [pan translationInView:parent];
    CGSize  sc     = UIScreen.mainScreen.bounds.size;

    CGPoint c = CGPointMake(
        _fabButton.center.x + delta.x,
        _fabButton.center.y + delta.y);

    // Clamp
    c.x = MAX(kBtnSize/2 + 6,
              MIN(sc.width  - kBtnSize/2 - 6, c.x));
    c.y = MAX(kBtnSize/2 + 50,
              MIN(sc.height - kBtnSize/2 - 30, c.y));

    _fabButton.center = c;
    [pan setTranslation:CGPointZero inView:parent];

    if (pan.state == UIGestureRecognizerStateEnded ||
        pan.state == UIGestureRecognizerStateCancelled) {

        // Snap sang cạnh gần nhất
        CGFloat snapX = (c.x > sc.width / 2)
            ? sc.width  - kBtnSize/2 - 6
            : kBtnSize/2 + 6;

        [UIView animateWithDuration:0.28
                              delay:0
             usingSpringWithDamping:0.72
              initialSpringVelocity:0.4
                            options:UIViewAnimationOptionCurveEaseOut
                         animations:^{
            self->_fabButton.center =
                CGPointMake(snapX, self->_fabButton.center.y);
        } completion:^(BOOL done) {
            if (self->_menuOpen) [self positionPanel];
        }];
    }
}

// ═══════════════════════════════════════════════════════════════
#pragma mark - Build Panel
// ═══════════════════════════════════════════════════════════════

- (void)buildPanel:(UIView *)parent {

    // ── Container ──
    _menuPanel = [[UIView alloc]
        initWithFrame:CGRectMake(0, 0, kPanelW, kPanelH)];
    _menuPanel.backgroundColor =
        [UIColor colorWithRed:0.07
                        green:0.07
                         blue:0.12
                        alpha:0.97];
    _menuPanel.layer.cornerRadius  = 18.f;
    _menuPanel.layer.masksToBounds = YES;
    _menuPanel.layer.borderWidth   = 1.f;
    _menuPanel.layer.borderColor   =
        [UIColor colorWithWhite:0.22 alpha:1].CGColor;
    _menuPanel.hidden = YES;
    _menuPanel.alpha  = 0;

    // ── Header ──
    UIView *header = [[UIView alloc]
        initWithFrame:CGRectMake(0, 0, kPanelW, kHeaderH)];
    header.backgroundColor =
        [UIColor colorWithRed:0.1
                        green:0.1
                         blue:0.18
                        alpha:1.0];

    UILabel *title = [[UILabel alloc]
        initWithFrame:CGRectMake(14, 0, kPanelW - 90, kHeaderH)];
    title.text      = @"⚡ App Switcher";
    title.textColor = UIColor.whiteColor;
    title.font      =
        [UIFont boldSystemFontOfSize:14];
    [header addSubview:title];

    // Badge đếm app
    UILabel *badge = [[UILabel alloc]
        initWithFrame:CGRectMake(kPanelW - 86, 10, 40, 26)];
    badge.tag             = 101;
    badge.text            = @"0";
    badge.textColor       =
        [UIColor colorWithRed:0.4 green:0.75 blue:1.0 alpha:1.0];
    badge.font            = [UIFont boldSystemFontOfSize:11];
    badge.textAlignment   = NSTextAlignmentCenter;
    badge.backgroundColor =
        [UIColor colorWithRed:0.15 green:0.25 blue:0.45 alpha:1.0];
    badge.layer.cornerRadius  = 8;
    badge.layer.masksToBounds = YES;
    [header addSubview:badge];

    // Nút Refresh
    UIButton *refreshBtn =
        [UIButton buttonWithType:UIButtonTypeSystem];
    refreshBtn.frame =
        CGRectMake(kPanelW - 42, 7, 32, 32);
    UIImageSymbolConfiguration *cfg =
        [UIImageSymbolConfiguration
            configurationWithPointSize:13
                                weight:UIImageSymbolWeightMedium];
    [refreshBtn setImage:
        [UIImage systemImageNamed:@"arrow.clockwise"
               withConfiguration:cfg]
               forState:UIControlStateNormal];
    refreshBtn.tintColor =
        [UIColor colorWithWhite:0.55 alpha:1];
    [refreshBtn addTarget:self
                   action:@selector(refreshApps)
         forControlEvents:UIControlEventTouchUpInside];
    [header addSubview:refreshBtn];

    // Separator dưới header
    UIView *sep = [[UIView alloc]
        initWithFrame:CGRectMake(0, kHeaderH - 0.5,
                                 kPanelW, 0.5)];
    sep.backgroundColor =
        [UIColor colorWithWhite:0.2 alpha:1];
    [header addSubview:sep];

    [_menuPanel addSubview:header];

    // ── Spinner ──
    _spinner =
        [[UIActivityIndicatorView alloc]
            initWithActivityIndicatorStyle:
                UIActivityIndicatorViewStyleMedium];
    _spinner.center =
        CGPointMake(kPanelW/2,
                    kHeaderH + (kPanelH - kHeaderH)/2);
    _spinner.color  = [UIColor colorWithWhite:0.4 alpha:1];
    _spinner.hidesWhenStopped = YES;
    [_menuPanel addSubview:_spinner];

    // ── TableView ──
    _tableView = [[UITableView alloc]
        initWithFrame:CGRectMake(0, kHeaderH,
                                 kPanelW,
                                 kPanelH - kHeaderH)
        style:UITableViewStylePlain];
    _tableView.backgroundColor = UIColor.clearColor;
    _tableView.separatorColor  =
        [UIColor colorWithWhite:0.18 alpha:1];
    _tableView.separatorInset  =
        UIEdgeInsetsMake(0, 56, 0, 0);
    _tableView.rowHeight       = kRowHeight;
    _tableView.dataSource      = self;
    _tableView.delegate        = self;
    _tableView.showsVerticalScrollIndicator = YES;
    [_menuPanel addSubview:_tableView];

    // ── Empty label ──
    _emptyLabel = [[UILabel alloc]
        initWithFrame:CGRectMake(0, kHeaderH,
                                 kPanelW,
                                 kPanelH - kHeaderH)];
    _emptyLabel.text =
        @"Không có app nào đang chạy";
    _emptyLabel.textColor   =
        [UIColor colorWithWhite:0.35 alpha:1];
    _emptyLabel.font        =
        [UIFont systemFontOfSize:13];
    _emptyLabel.textAlignment = NSTextAlignmentCenter;
    _emptyLabel.hidden = YES;
    [_menuPanel addSubview:_emptyLabel];

    // ── Tap ngoài để đóng ──
    UITapGestureRecognizer *tapOut =
        [[UITapGestureRecognizer alloc]
            initWithTarget:self
                    action:@selector(closeMenu)];
    tapOut.cancelsTouchesInView = NO;
    [parent addGestureRecognizer:tapOut];

    [parent addSubview:_menuPanel];
}

// ─── Tính vị trí panel cạnh FAB ────────────────────────────────
- (void)positionPanel {
    CGSize  sc    = UIScreen.mainScreen.bounds.size;
    CGPoint fab   = _fabButton.center;
    BOOL    right = fab.x > sc.width / 2;

    CGFloat x = right
        ? fab.x - kBtnSize/2 - kPanelW - 10
        : fab.x + kBtnSize/2 + 10;

    CGFloat y = fab.y - kPanelH / 2;
    y = MAX(50, MIN(sc.height - kPanelH - 20, y));

    _menuPanel.frame = CGRectMake(x, y, kPanelW, kPanelH);
}

// ═══════════════════════════════════════════════════════════════
#pragma mark - Open / Close Menu
// ═══════════════════════════════════════════════════════════════

- (void)openMenu {
    [self positionPanel];
    _menuPanel.hidden    = NO;
    _menuPanel.transform =
        CGAffineTransformMakeScale(0.82, 0.82);

    [UIView animateWithDuration:0.28
                          delay:0
         usingSpringWithDamping:0.72
          initialSpringVelocity:0.5
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
        self->_menuPanel.alpha     = 1.0;
        self->_menuPanel.transform =
            CGAffineTransformIdentity;
    } completion:nil];

    [self setFABIcon:@"xmark"];
    _menuOpen = YES;
    [self refreshApps];
}

- (void)closeMenu {
    if (!_menuOpen) return;

    [UIView animateWithDuration:0.2
                     animations:^{
        self->_menuPanel.alpha     = 0;
        self->_menuPanel.transform =
            CGAffineTransformMakeScale(0.88, 0.88);
    } completion:^(BOOL done) {
        self->_menuPanel.hidden    = YES;
        self->_menuPanel.transform =
            CGAffineTransformIdentity;
    }];

    [self setFABIcon:@"square.grid.2x2.fill"];
    _menuOpen = NO;
}

// ═══════════════════════════════════════════════════════════════
#pragma mark - Fetch Running Apps
// ═══════════════════════════════════════════════════════════════

- (void)refreshApps {
    [_spinner startAnimating];
    _tableView.hidden  = YES;
    _emptyLabel.hidden = YES;

    dispatch_async(
        dispatch_get_global_queue(
            DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{

        NSMutableArray *list = [NSMutableArray array];

        CFArrayRef raw =
            SBSCopyApplicationDisplayIdentifiers(YES, NO);
        if (raw) {
            NSArray *ids =
                (__bridge_transfer NSArray *)raw;

            // Bỏ qua system processes
            NSSet *skip = [NSSet setWithArray:@[
                @"com.apple.springboard",
                @"com.apple.home",
                @"com.apple.mobileslideshow",
                @"com.apple.Preferences"
            ]];

            for (NSString *bid in ids) {
                if ([skip containsObject:bid]) continue;
                AppEntry *e   = [AppEntry new];
                e.bundleID    = bid;
                e.displayName = [self nameForBundle:bid];
                e.icon        = [self iconForBundle:bid];
                [list addObject:e];
            }
        }

        dispatch_async(dispatch_get_main_queue(), ^{
            self->_apps = list;
            [self->_spinner stopAnimating];

            BOOL hasApps = list.count > 0;
            self->_tableView.hidden  = !hasApps;
            self->_emptyLabel.hidden =  hasApps;

            // Update badge
            UILabel *badge =
                (UILabel *)[self->_menuPanel viewWithTag:101];
            badge.text =
                [NSString stringWithFormat:@"%lu",
                 (unsigned long)list.count];

            [self->_tableView reloadData];
        });
    });
}

// ─── Lấy tên app ───────────────────────────────────────────────
- (NSString *)nameForBundle:(NSString *)bid {
    NSArray *bases = @[
        @"/var/containers/Bundle/Application",
        @"/Applications"
    ];
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *base in bases) {
        NSArray *dirs =
            [fm contentsOfDirectoryAtPath:base error:nil];
        for (NSString *dir in dirs) {
            NSString *full =
                [base stringByAppendingPathComponent:dir];
            NSBundle *b = [NSBundle bundleWithPath:full];
            if (![b.bundleIdentifier
                    isEqualToString:bid]) continue;
            NSString *name =
                b.infoDictionary[@"CFBundleDisplayName"]
                ?: b.infoDictionary[@"CFBundleName"];
            if (name) return name;
        }
    }
    // Fallback: phần cuối của bundleID
    NSArray *parts = [bid componentsSeparatedByString:@"."];
    return parts.lastObject ?: bid;
}

// ─── Lấy icon app ──────────────────────────────────────────────
- (UIImage *)iconForBundle:(NSString *)bid {
    // Thử UIImage private API
    UIImage *img =
        [UIImage _applicationIconImageForBundleIdentifier:bid
                                           roleIdentifier:nil
                                                   format:0
                                                    scale:
         UIScreen.mainScreen.scale];
    if (img) return img;

    // Fallback SF Symbol
    UIImageSymbolConfiguration *cfg =
        [UIImageSymbolConfiguration
            configurationWithPointSize:24
                                weight:UIImageSymbolWeightRegular];
    return [UIImage systemImageNamed:@"app.fill"
                   withConfiguration:cfg];
}

// ═══════════════════════════════════════════════════════════════
#pragma mark - UITableView DataSource
// ═══════════════════════════════════════════════════════════════

- (NSInteger)tableView:(UITableView *)tv
 numberOfRowsInSection:(NSInteger)s {
    return _apps.count;
}

- (UITableViewCell *)tableView:(UITableView *)tv
         cellForRowAtIndexPath:(NSIndexPath *)ip {

    static NSString *ID = @"AppCell";
    UITableViewCell *cell =
        [tv dequeueReusableCellWithIdentifier:ID];

    if (!cell) {
        cell = [[UITableViewCell alloc]
            initWithStyle:UITableViewCellStyleSubtitle
           reuseIdentifier:ID];
        cell.backgroundColor = UIColor.clearColor;

        cell.textLabel.textColor = UIColor.whiteColor;
        cell.textLabel.font =
            [UIFont systemFontOfSize:13
                              weight:UIFontWeightMedium];

        cell.detailTextLabel.textColor =
            [UIColor colorWithWhite:0.42 alpha:1];
        cell.detailTextLabel.font =
            [UIFont systemFontOfSize:10];

        // Highlight khi chọn
        UIView *sel = [[UIView alloc] init];
        sel.backgroundColor =
            [UIColor colorWithRed:0.18
                            green:0.38
                             blue:0.78
                            alpha:0.25];
        cell.selectedBackgroundView = sel;

        // Chevron indicator
        cell.accessoryView = nil;
        UIImageSymbolConfiguration *c2 =
            [UIImageSymbolConfiguration
                configurationWithPointSize:10
                                    weight:UIImageSymbolWeightLight];
        UIImageView *arrow = [[UIImageView alloc]
            initWithImage:
                [UIImage systemImageNamed:@"chevron.right"
                        withConfiguration:c2]];
        arrow.tintColor =
            [UIColor colorWithWhite:0.3 alpha:1];
        cell.accessoryView = arrow;
    }

    AppEntry *app              = _apps[ip.row];
    cell.textLabel.text        = app.displayName;
    cell.detailTextLabel.text  = app.bundleID;
    cell.imageView.image       = app.icon;
    cell.imageView.tintColor   =
        [UIColor colorWithRed:0.4 green:0.75 blue:1.0 alpha:1];
    cell.imageView.layer.cornerRadius  = 9;
    cell.imageView.layer.masksToBounds = YES;
    cell.imageView.contentMode =
        UIViewContentModeScaleAspectFit;
    cell.imageView.frame =
        CGRectMake(0, 0, 32, 32);
    return cell;
}

// ═══════════════════════════════════════════════════════════════
#pragma mark - UITableView Delegate
// ═══════════════════════════════════════════════════════════════

- (void)tableView:(UITableView *)tv
didSelectRowAtIndexPath:(NSIndexPath *)ip {
    [tv deselectRowAtIndexPath:ip animated:YES];

    if (ip.row >= (NSInteger)_apps.count) return;
    AppEntry *app = _apps[ip.row];

    [self closeMenu];

    // Switch app sau khi animation đóng xong
    dispatch_after(
        dispatch_time(DISPATCH_TIME_NOW,
                      (int64_t)(0.28 * NSEC_PER_SEC)),
        dispatch_get_main_queue(), ^{
            SBSLaunchApplicationWithIdentifier(
                (__bridge CFStringRef)app.bundleID, NO);
    });
}

- (CGFloat)tableView:(UITableView *)tv
heightForRowAtIndexPath:(NSIndexPath *)ip {
    return kRowHeight;
}

@end
