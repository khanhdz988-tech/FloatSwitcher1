#import "FloatingMenuManager.h"

%hook UIApplication

- (void)applicationDidBecomeActive:(UIApplication *)application {
    %orig;

    static dispatch_once_t once;
    dispatch_once(&once, ^{
        dispatch_async(dispatch_get_main_queue(), ^{

            // Tìm key window
            UIWindow *keyWindow = nil;

            if (@available(iOS 13.0, *)) {
                for (UIWindowScene *scene in
                     UIApplication.sharedApplication.connectedScenes) {
                    if (![scene isKindOfClass:
                          [UIWindowScene class]]) continue;
                    for (UIWindow *w in
                         ((UIWindowScene *)scene).windows) {
                        if (w.isKeyWindow) {
                            keyWindow = w;
                            break;
                        }
                    }
                    if (keyWindow) break;
                }
            } else {
                keyWindow =
                    UIApplication.sharedApplication.keyWindow;
            }

            if (keyWindow) {
                [[FloatingMenuManager shared]
                    installOverlayInWindow:keyWindow];
            }
        });
    });
}

%end
